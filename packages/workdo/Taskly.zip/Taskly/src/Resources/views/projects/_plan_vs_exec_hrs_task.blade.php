<div class="row mt-3">
  <div class="col-md-4">
    <div class="card shadow-sm">
      <div class="card-body">
        <h6 class="mb-2">Estimated hours</h6>
        <div class="h4 mb-0">
          {{ number_format($task->estimated_hours ?? 0, 2) }}
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card shadow-sm">
      <div class="card-body">
        <h6 class="mb-2">Worked hours</h6>
        <div class="h4 mb-0">
          {{ number_format($task->actual_hours, 2) }}
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-4">
    @php
      $variance = $task->hours_variance; // estimado - real
      $badge  = is_null($variance) ? 'secondary' : ($variance >= 0 ? 'success' : 'danger');
    @endphp
    <div class="card shadow-sm">
      <div class="card-body">
        <h6 class="mb-2">Difference</h6>
        <span class="badge badge-{{ $badge }}">
          {{ is_null($variance) ? '—' : number_format($variance, 2) }} h
        </span>
      </div>
    </div>
  </div>
</div>

{{-- resources/views/projects/show.blade.php --}}
<div class="row mt-3">
  <div class="col-md-4">
    <div class="card shadow-sm">
      <div class="card-body">
        <h6 class="mb-2">Horas estimadas</h6>
        <div class="h4 mb-0">
          {{ number_format($project->estimated_hours ?? 0, 2) }}
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card shadow-sm">
      <div class="card-body">
        <h6 class="mb-2">Horas reales</h6>
        <div class="h4 mb-0">
          {{ number_format($project->actual_hours, 2) }}
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-4">
    @php
      $variance = $project->hours_variance; // estimado - real
      $badge  = is_null($variance) ? 'secondary' : ($variance >= 0 ? 'success' : 'danger');
    @endphp
    <div class="card shadow-sm">
      <div class="card-body">
        <h6 class="mb-2">Diferencia</h6>
        <span class="badge badge-{{ $badge }}">
          {{ is_null($variance) ? '—' : number_format($variance, 2) }} h
        </span>
      </div>
    </div>
  </div>
</div>

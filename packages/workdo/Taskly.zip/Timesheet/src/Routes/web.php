<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use Illuminate\Support\Facades\Route;
use Workdo\Timesheet\Http\Controllers\TimesheetController;

Route::group([
    'middleware' => ['web','auth','verified','PlanModuleCheck:Timesheet'],
], function () {
    // CRUD principal (registra timesheet.index, .create, .store, etc.)
    Route::resource('timesheet', TimesheetController::class);

    // AJAX: clientes por proyecto / por customer
    Route::get('timesheet/clients/by-project',  [TimesheetController::class, 'getCustomerClientsByProject'])
        ->name('timesheet.clients.by-project');
    Route::get('timesheet/clients/by-customer', [TimesheetController::class, 'getCustomerClientsByCustomer'])
        ->name('timesheet.clients.by-customer');

    Route::post('timesheet/bulk-validate', [TimesheetController::class, 'bulkValidate'])
        ->name('timesheet.bulk-validate');
        
    Route::post('timesheet/bulk-unvalidate', [TimesheetController::class, 'bulkUnvalidate'])
    ->name('timesheet.bulk-unvalidate');
    
    // Otros endpoints usados por el formulario
    Route::get('/totalhours',              [TimesheetController::class, 'totalhours'])->name('totalhours');
    Route::get('gethours/{id}',            [TimesheetController::class, 'gethours'])->name('gethours');
    Route::post('/gettask',                [TimesheetController::class, 'gettask'])->name('gettask');
});

<?php

namespace Workdo\Timesheet\Entities;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Timesheet extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id','project_id','task_id','date',
        'hours','minutes','description','notes',
        'workspace_id','created_by','type',
        'validated','invoiced','paid',
        'from_time','to_time','customer_id',
        'customer_client_id'
    ];

    protected $casts = [
        'validated' => 'boolean',
        'invoiced'  => 'boolean',
        'paid'      => 'boolean',
    ];

    protected static function newFactory()
    {
        return \Workdo\Timesheet\Database\factories\TimesheetFactory::new();
    }

    public function user()
    {
        return $this->hasOne(User::class, 'id', 'user_id');
    }
}

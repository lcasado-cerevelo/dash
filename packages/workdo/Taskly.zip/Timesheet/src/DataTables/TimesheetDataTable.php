<?php

namespace Workdo\Timesheet\DataTables;

use Illuminate\Database\Eloquent\Builder as QueryBuilder;
use Illuminate\Support\Facades\Auth;
// OJO: ajusta este use al namespace real de tu modelo Timesheet:
use Workdo\Taskly\Entities\Timesheet;
use Yajra\DataTables\EloquentDataTable;
use Yajra\DataTables\Html\Builder as HtmlBuilder;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Services\DataTable;
use Illuminate\Support\Facades\DB;

class TimesheetDataTable extends DataTable
{
    public function dataTable(QueryBuilder $query): EloquentDataTable
    {
        $rowColumn = ['bulk', 'user_name', 'project_id', 'customer_client_id', 'validated', 'billed', 'paid'];
        $canInvoice = \Laratrust::hasRole('super admin')
            || \Laratrust::hasPermission([
                'invoice manage',
                'invoice view',
                'invoice show',
                'invoice create',
                'invoice edit',
                'invoice delete'
            ]);
        $canBilled = !\Laratrust::hasRole(['Customer','Client']);
         
        $dataTable = (new EloquentDataTable($query))
            ->addIndexColumn()

            // Checkbox por fila
            ->addColumn('bulk', function (Timesheet $row) {
                return sprintf(
                    '<div class="text-center">
                       <input type="checkbox" class="ts-bulk"
                              value="%d"
                              data-validated="%d"
                              data-billed="%d"
                              data-invoiced="%d"
                              data-paid="%d">
                     </div>',
                    $row->id,
                    (int) $row->validated,
                    (int) $row->billed,
                    (int) ($row->invoiced ?? 0),
                    (int) $row->paid
                );
            })
            ->addColumn('total', function (Timesheet $m) {
                return sprintf('%02d:%02d', (int)$m->hours, (int)$m->minutes);
            })
            ->editColumn('user_name', function (Timesheet $model) {
                return $model->user_name ?? '-';
            })
            ->editColumn('project_id', function (Timesheet $model) {
                return $model->project_name ?? '-';
            })
            ->editColumn('customer_client_id', function (Timesheet $model) {
                return $model->client_name ?? '-';
            })
            ->addColumn('validated', function (Timesheet $m) {
                $checked = $m->validated ? 'checked' : '';
                return '<div class="text-center"><input type="checkbox" class="form-check-input m-0 ts-readonly" '.$checked.'></div>';
            });
            
            if ($canBilled) {
                $dataTable->addColumn('billed', function (Timesheet $m) {
                    $checked = $m->billed ? 'checked' : '';
                    return '<div class="text-center"><input type="checkbox" class="form-check-input m-0 ts-readonly" '.$checked.'></div>';
                })
                ->addColumn('paid', function (Timesheet $m) {
                    $checked = $m->paid ? 'checked' : '';
                    return '<div class="text-center"><input type="checkbox" class="form-check-input m-0 ts-readonly" '.$checked.'></div>';
                });
            }
            if ($canInvoice) {
                $dataTable->addColumn('invoiced', function (Timesheet $m) {
                    $checked = $m->invoiced ? 'checked' : '';
                    return '<div class="text-center"><input type="checkbox" class="form-check-input m-0 ts-readonly" '.$checked.'></div>';
                });
                $rowColumn[] = 'invoiced';
            }
            
        if (\Laratrust::hasPermission('timesheet edit') || \Laratrust::hasPermission('timesheet delete')) {
            $dataTable->addColumn('action', function (Timesheet $timesheet) {
                return view('timesheet::timesheet.action', compact('timesheet'));
            });
            $rowColumn[] = 'action';
        }

        // Asegura que 'bulk' se renderice como HTML
        return $dataTable->rawColumns($rowColumn);
    }

    public function query(Timesheet $model): QueryBuilder
    {
        // Rango por defecto: mes actual
        $from = request('date_from') ?: now()->startOfMonth()->toDateString();
        $to   = request('date_to')   ?: now()->endOfMonth()->toDateString();
    
        // Status desde las tabs
        $status = request('status');
    
        // Query base (joins + columnas)
        $q = $model->newQuery()
            ->select(
                'timesheets.*',
                'users.name as user_name',
                'projects.name as project_name',
                'customer_clients.name as client_name'
            )
            ->leftJoin('users', 'timesheets.user_id', '=', 'users.id')
            ->leftJoin('customer_clients', 'timesheets.customer_client_id', '=', 'customer_clients.id')
            ->leftJoin('projects', 'timesheets.project_id', '=', 'projects.id')
            ->where('timesheets.created_by', creatorId())
            ->where('timesheets.workspace_id', getActiveWorkSpace())
            ->whereBetween('timesheets.date', [$from, $to]);
    
        $user          = Auth::user();
        $isSuperAdmin  = \Laratrust::hasRole('super admin');
        $canManageTs   = \Laratrust::hasPermission('timesheet manage');
        $isCustomerLike= \Laratrust::hasRole(['Customer','Client']);
    
        // ===== Visibilidad por rol =====
        $allowedProjectIds = [];
        $allowedClientIds  = [];
    
        if ($isCustomerLike) {
            // Proyectos donde este usuario es "cliente"
            $projectIdsAsClient = DB::table('client_projects')
                ->where('client_id', $user->id)
                ->pluck('project_id');
    
            // (Opcional) Proyectos donde este usuario es miembro
            $projectIdsAsMember = DB::table('user_projects')
                ->where('user_id', $user->id)
                ->pluck('project_id');
    
            $allowedProjectIds = $projectIdsAsClient->merge($projectIdsAsMember)->unique()->all();
    
            // Customers asignados al usuario
            $customerIds = DB::table('customer_users')
                ->where('user_id', $user->id)
                ->pluck('customer_id');
    
            // CustomerClients asignados DIRECTAMENTE al usuario
            $ccIdsDirect = DB::table('customer_clients_users')
                ->where('user_id', $user->id)
                ->pluck('customer_client_id');
    
            // CustomerClients VÍA customers asignados
            $ccIdsViaCustomer = $customerIds->isNotEmpty()
                ? DB::table('customer_clients')->whereIn('customer_id', $customerIds)->pluck('id')
                : collect();
    
            $allowedClientIds = $ccIdsDirect->merge($ccIdsViaCustomer)->unique()->all();
    
            // Si no tiene nada asignado, no debe ver registros
            if (empty($allowedProjectIds) && empty($allowedClientIds)) {
                $q->whereRaw('0=1');
            } else {
                $q->where(function($w) use ($allowedProjectIds, $allowedClientIds) {
                    if (!empty($allowedProjectIds))  $w->orWhereIn('timesheets.project_id', $allowedProjectIds);
                    if (!empty($allowedClientIds))   $w->orWhereIn('timesheets.customer_client_id', $allowedClientIds);
                });
            }
        } else {
            // Si NO es super admin ni puede "manage", limitar a sí mismo
            if (!$isSuperAdmin && !$canManageTs) {
                $q->where('timesheets.user_id', $user->id);
            }
        }
    
        // ===== Filtros recibidos (intersecados con lo permitido cuando corresponde) =====
    
        // Clients
        $clientIds = array_filter((array) request('client_ids', []));
        if (!empty($clientIds)) {
            if ($isCustomerLike) {
                // blindaje: que sólo filtre por clientes visibles
                $clientIds = array_values(array_intersect($clientIds, $allowedClientIds));
                if (empty($clientIds)) {
                    // pidió clientes fuera de su perímetro → 0 filas
                    $q->whereRaw('0=1');
                }
            }
            if (!empty($clientIds)) {
                $q->whereIn('timesheets.customer_client_id', $clientIds);
            }
        }
    
        // Consultants
        $consultantIds = array_filter((array) request('consultant_ids', []));
        if (!empty($consultantIds)) {
            if ($isCustomerLike) {
                // "Consultants visibles" = usuarios asignados a proyectos visibles
                //   + usuarios que han registrado TS contra esos projects/clients visibles
                $visibleConsultantIds = collect();
    
                if (!empty($allowedProjectIds)) {
                    $visibleConsultantIds = $visibleConsultantIds->merge(
                        DB::table('user_projects')->whereIn('project_id', $allowedProjectIds)->pluck('user_id')
                    );
                }
    
                if (!empty($allowedProjectIds) || !empty($allowedClientIds)) {
                    $tsUsers = DB::table('timesheets')
                        ->where('created_by', creatorId())
                        ->where('workspace_id', getActiveWorkSpace())
                        ->when(!empty($allowedProjectIds), function($qq) use ($allowedProjectIds) {
                            $qq->whereIn('project_id', $allowedProjectIds);
                        })
                        ->when(!empty($allowedClientIds), function($qq) use ($allowedClientIds) {
                            $qq->orWhereIn('customer_client_id', $allowedClientIds);
                        })
                        ->pluck('user_id');
    
                    $visibleConsultantIds = $visibleConsultantIds->merge($tsUsers);
                }
    
                $visibleConsultantIds = $visibleConsultantIds->unique()->all();
                $consultantIds = array_values(array_intersect($consultantIds, $visibleConsultantIds));
    
                if (empty($consultantIds)) {
                    $q->whereRaw('0=1');
                }
            } else {
                // Sólo permitimos filtrar por consultants si hay “gestión” o super admin
                if (!($isSuperAdmin || $canManageTs)) {
                    // sin permisos para decidir consultants → no aplicar filtro ajeno (o forzar al propio)
                    $consultantIds = [$user->id];
                }
            }
    
            if (!empty($consultantIds)) {
                $q->whereIn('timesheets.user_id', $consultantIds);
            }
        }
    
        // ===== Status =====
        if ($status && $status !== 'All') {
            switch ($status) {
                case 'Unapproved': $q->where('timesheets.validated', false); break;
                case 'Approved':   $q->where('timesheets.validated', true);  break;
                case 'Billed':     $q->where('timesheets.billed', true);     break;
                case 'Paid':       $q->where('timesheets.paid', true);       break;
                case 'Invoiced':   $q->where('timesheets.invoiced', true);   break;
            }
        }
    
        return $q;
}


    public function html(): HtmlBuilder
    {
        $builder = $this->builder()
            ->setTableId('timesheets-table')
            ->columns($this->getColumns())
            ->ajax([
                'url' => route('timesheet.index'),
                'type' => 'GET', 
                'data' => 'function(d){
                                d.date_from = $("#filter-date-from").val();
                                d.date_to = $("#filter-date-to").val();
                            }',
                ])
            ->orderBy(0)
            ->parameters([
                'responsive' => true,
                'autoWidth'  => false,
            ])
            ->language([
                "paginate" => [
                    "next" => '<i class="ti ti-chevron-right"></i>',
                    "previous" => '<i class="ti ti-chevron-left"></i>'
                ],
                'lengthMenu' => "_MENU_" . __('Entries Per Page'),
                "searchPlaceholder" => __('Search...'),
                "search" => "",
                "info" => __('Showing _START_ to _END_ of _TOTAL_ entries')
            ])
            ->initComplete('function() {
                var table = this;
                var searchInput = $(\'#\'+table.api().table().container().id+\' label input[type="search"]\');
                searchInput.removeClass(\'form-control form-control-sm\');
                searchInput.addClass(\'dataTable-input\');
                $(table.api().table().container())
                    .find(".dataTables_length select")
                    .removeClass(\'custom-select custom-select-sm form-control form-control-sm\')
                    .addClass(\'dataTable-selector\');
            }');


        // Botones existentes
        $exportButtonConfig = [
            'extend' => 'collection',
            'className' => 'btn btn-light-secondary dropdown-toggle',
            'text' => '<i class="ti ti-download me-2" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Export"></i>',
            'buttons' => [
                [
                    'extend' => 'print',
                    'text' => '<i class="fas fa-print me-2"></i> ' . __('Print'),
                    'className' => 'btn btn-light text-primary dropdown-item',
                    'exportOptions' => ['columns' => [0, 1, 3]],
                ],
                [
                    'extend' => 'csv',
                    'text' => '<i class="fas fa-file-csv me-2"></i> ' . __('CSV'),
                    'className' => 'btn btn-light text-primary dropdown-item',
                    'exportOptions' => ['columns' => [0, 1, 3]],
                ],
                [
                    'extend' => 'excel',
                    'text' => '<i class="fas fa-file-excel me-2"></i> ' . __('Excel'),
                    'className' => 'btn btn-light text-primary dropdown-item',
                    'exportOptions' => ['columns' => [0, 1, 3]],
                ],
            ],
        ];

        $buttonsConfig = [
            $exportButtonConfig,
            [
                'extend' => 'reset',
                'className' => 'btn btn-light-danger',
            ],
            [
                'extend' => 'reload',
                'className' => 'btn btn-light-warning',
            ],
        ];

        if (\Laratrust::hasPermission('timesheet validate')) {
            $buttonsConfig[] = [
                'text' => '<i class="ti ti-check me-1"></i> ' . __('Validate'),
                'className' => 'btn btn-success',
                'attr' => ['id' => 'btn-validate'],
            ];
        }

        $builder->parameters([
            "dom" =>  "
                <'dataTable-top'
                    <'dataTable-dropdown page-dropdown'l>
                    <'dataTable-botton table-btn dataTable-search tb-search d-flex justify-content-end gap-2'Bf>
                >
                <'dataTable-container'<'col-sm-12'tr>>
                <'dataTable-bottom row'<'col-5'i><'col-7'p>>",
            'buttons' => $buttonsConfig,
            "drawCallback" => 'function(settings) {
                var tooltipTriggerList = [].slice.call(document.querySelectorAll("[data-bs-toggle=tooltip]"));
                tooltipTriggerList.map(function (el) { return new bootstrap.Tooltip(el); });
                document.querySelectorAll("[data-bs-toggle=tooltip]").forEach(function(el){
                      if (!bootstrap.Tooltip.getInstance(el)) new bootstrap.Tooltip(el, {container:"body"});
                    });        
                $("#ts-bulk-all").prop("checked", false);
                $(".ts-bulk").prop("checked", false);
        
                $("#btn-validate,#btn-unvalidate").prop("disabled", true);
            }'
        ]);

        $builder->language([
            'buttons' => [
                'create' => __('Create'),
                'export' => __('Export'),
                'print' => __('Print'),
                'reset' => __('Reset'),
                'reload' => __('Reload'),
                'excel' => __('Excel'),
                'csv' => __('CSV'),
            ]
        ]);

        return $builder;
    }

    public function getColumns(): array
    {
        $columns = [
            Column::make('id')->searchable(false)->visible(false)->visible(false)->exportable(false)->printable(false),

            // No
            Column::make('No')->title(__('No'))
                ->data('DT_RowIndex')->name('DT_RowIndex')
                ->searchable(false)->orderable(false)
                ->visible(false)                 // <--- Oculta en la tabla
                ->exportable(false)->printable(false),
            
            // Checkbox header (select all)
            Column::computed('bulk')
                ->title('<div class="text-center">
                           <input type="checkbox" id="ts-bulk-all"
                                  data-bs-toggle="tooltip"
                                  data-bs-placement="bottom"
                                  data-bs-trigger="hover"
                                  title="Select All">
                         </div>')
                ->exportable(false)->printable(false)->orderable(false)->searchable(false)
                ->width(30),
            Column::make('user_name')->title(__('Employee'))->name('users.name'),
            Column::make('project_id')->title(__('Project'))->name('projects.name'),
            Column::make('customer_client_id')->title(__('Client'))->name('customer_clients.name'),
            Column::make('date')->title(__('Date'))->addClass('text-center'),
            Column::make('total')->title(__('Total'))->addClass('text-center'),            
            Column::computed('validated')->title(__('Approved'))
                ->exportable(false)->printable(true)->orderable(false)->searchable(false)->width(60)->addClass('text-center'),

        ];

     $canBilled = !\Laratrust::hasRole(['Customer','Client']);


     $canInvoice = \Laratrust::hasPermission('invoice manage')
            || \Laratrust::hasPermission('invoice view')
            || \Laratrust::hasPermission('invoice show')
            || \Laratrust::hasPermission('invoice create')
            || \Laratrust::hasPermission('invoice edit')
            || \Laratrust::hasPermission('invoice delete');

        if ($canInvoice) {
            $columns[] = [Column::computed('billed')->title(__('Billed'))
                ->exportable(false)->printable(true)->orderable(false)->searchable(false)->width(60)->addClass('text-center'),
                Column::computed('paid')->title(__('Paid'))
                ->exportable(false)->printable(true)->orderable(false)->searchable(false)->width(60)->addClass('text-center')];
        }

    
        if ($canInvoice) {
            $columns[] = Column::computed('invoiced')->title(__('Invoiced'))
                ->exportable(false)->printable(true)->orderable(false)->searchable(false)->width(60)->addClass('text-center');
        }
    
        if (\Laratrust::hasPermission('timesheet edit') || \Laratrust::hasPermission('timesheet delete')) {
            $columns[] = Column::computed('action')
                ->title(__('Action'))
                ->exportable(false)
                ->printable(false)
                ->width(60);
        }

        return $columns;
    }

    protected function filename(): string
    {
        return 'Timesheets' . date('YmdHis');
    }
}
